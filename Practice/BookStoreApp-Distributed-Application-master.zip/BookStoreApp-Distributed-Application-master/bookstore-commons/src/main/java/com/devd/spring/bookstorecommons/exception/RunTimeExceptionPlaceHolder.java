package com.devd.spring.bookstorecommons.exception;

/**
 * @author: Devaraj Reddy, Date : 2019-05-20
 */
public class RunTimeExceptionPlaceHolder extends RuntimeException {

  public RunTimeExceptionPlaceHolder(String message) {
    super(message);
  }
}
