package com.devd.spring.bookstorecatalogservice.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * @author: Devaraj Reddy,
 * Date : 2019-06-03
 */
@RestController
public class CatalogController {

}
