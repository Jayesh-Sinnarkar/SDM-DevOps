export const BACKEND_API_GATEWAY_URL = 'http://localhost:8765';
export const APP_CLIENT_ID = '93ed453e-b7ac-4192-a6d4-c45fae0d99ac';
export const APP_CLIENT_SECRET = 'client.devd123';
