# BookStore ReactJS App

This is the UI where customers can buy books and Admin can maintain inventory, orders, users etc.

## Run the App in Local Machine
 Install the required dependencies
```
    yarn install
```

Start the application.
```
    yarn start
```