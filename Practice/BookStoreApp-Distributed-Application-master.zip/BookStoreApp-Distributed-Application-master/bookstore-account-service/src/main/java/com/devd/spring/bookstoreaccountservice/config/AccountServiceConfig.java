package com.devd.spring.bookstoreaccountservice.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author: Devaraj Reddy, Date : 2019-07-14
 */
@Configuration
public class AccountServiceConfig {

}
